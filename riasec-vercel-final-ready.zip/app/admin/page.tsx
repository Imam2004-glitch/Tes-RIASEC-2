export default function AdminPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h2>Halaman Admin</h2>
      <p>Di sini nantinya admin bisa melihat rekap hasil tes siswa.</p>
    </main>
  );
}
