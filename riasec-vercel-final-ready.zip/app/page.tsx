export default function HomePage() {
  return (
    <main style={{ textAlign: 'center', paddingTop: '3rem' }}>
      <h1>Tes Minat dan Bakat RIASEC</h1>
      <p>Ketahui karirmu untuk merencanakan masa depanmu</p>
      <a href="/form-identitas" style={{
        display: 'inline-block',
        marginTop: '1rem',
        padding: '0.8rem 1.5rem',
        backgroundColor: '#0070f3',
        color: '#fff',
        textDecoration: 'none',
        borderRadius: '8px'
      }}>Mulai</a>
    </main>
  );
}
