export default function SoalPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h2>Contoh Soal RIASEC</h2>
      <form action="/hasil">
        <label><input type="checkbox" name="soal1" value="R" /> Saya suka bekerja dengan alat</label><br/>
        <label><input type="checkbox" name="soal2" value="I" /> Saya tertarik pada eksperimen ilmiah</label><br/><br/>
        <button type="submit">Lihat Hasil</button>
      </form>
    </main>
  );
}
