export default function HasilPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h2>Hasil Tes RIASEC</h2>
      <p>Hasil dan rekomendasi profesi akan ditampilkan di sini.</p>
    </main>
  );
}
