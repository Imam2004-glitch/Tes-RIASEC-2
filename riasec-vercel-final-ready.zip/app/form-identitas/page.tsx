export default function FormIdentitas() {
  return (
    <main style={{ padding: '2rem' }}>
      <h2>Form Identitas</h2>
      <form action="/soal">
        <label>
          Nama: <input type="text" name="nama" required />
        </label><br/><br/>
        <label>
          Kelas: <input type="text" name="kelas" required />
        </label><br/><br/>
        <button type="submit">Lanjut</button>
      </form>
    </main>
  );
}
